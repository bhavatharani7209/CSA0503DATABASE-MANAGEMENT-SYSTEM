-- Queries used by the dashboard (table: train, SQLite syntax)

-- ===== Module 1 — Dataset structure =====
-- Count rows and columns
SELECT COUNT(*) AS total_rows FROM train;

-- List the 12 columns
PRAGMA table_info(train);

-- Check missing and duplicate values
SELECT COUNT(*) AS total_rows,
       COUNT(*) - COUNT(DISTINCT PassengerId) AS duplicates,
       SUM(Age IS NULL) AS missing_age,
       SUM(Cabin IS NULL) AS missing_cabin,
       SUM(Embarked IS NULL) AS missing_port
FROM train;

-- ===== Module 1 — Cleaning =====
-- Median Age and missing-value checks
SELECT Age AS median_age
FROM train
WHERE Age IS NOT NULL
ORDER BY Age
LIMIT 1 OFFSET (SELECT COUNT(Age)/2 FROM train);

-- Fill missing values used by the project
UPDATE train SET Age = 28 WHERE Age IS NULL;
UPDATE train SET Embarked = 'S' WHERE Embarked IS NULL;

-- Cabin is removed during cleaning
ALTER TABLE train DROP COLUMN Cabin;

-- ===== Module 2 — Overall survival =====
SELECT COUNT(*) AS total_passengers,
       SUM(Survived) AS survivors,
       COUNT(*) - SUM(Survived) AS deaths,
       ROUND(100.0 * AVG(Survived), 1) AS survival_rate
FROM train;

-- ===== Module 2 — Sex, class and port =====
WITH groups AS (
  SELECT 'Sex: '||Sex AS grp, Survived FROM train
  UNION ALL SELECT 'Class: '||Pclass, Survived FROM train
  UNION ALL SELECT 'Port: '||Embarked, Survived FROM train
)
SELECT grp, COUNT(*) AS total,
       SUM(Survived) AS survived,
       ROUND(100.0 * AVG(Survived), 1) AS rate_pct
FROM groups GROUP BY grp ORDER BY grp;

-- ===== Module 2 — Age bands =====
SELECT CASE
         WHEN Age < 13 THEN 'Child (0–12)'
         WHEN Age < 20 THEN 'Teen (13–19)'
         WHEN Age < 36 THEN 'Young Adult (20–35)'
         WHEN Age < 61 THEN 'Adult (36–60)'
         ELSE 'Senior (61+)'
       END AS age_group,
       COUNT(*) AS total,
       SUM(Survived) AS survived,
       ROUND(100.0 * AVG(Survived), 1) AS rate_pct
FROM train
GROUP BY age_group;

-- ===== Chart 1 — Survival by sex =====
SELECT Sex, COUNT(*) AS total,
       SUM(Survived) AS survived,
       ROUND(100.0*AVG(Survived),1) AS survival_rate
FROM train GROUP BY Sex;

-- ===== Chart 2 — Survival by class =====
SELECT Pclass, COUNT(*) AS total,
       SUM(Survived) AS survived,
       ROUND(100.0*AVG(Survived),1) AS survival_rate
FROM train GROUP BY Pclass ORDER BY Pclass;

-- ===== Chart 3 — Survival by age group =====
SELECT CASE WHEN Age < 13 THEN 'Child'
       WHEN Age < 20 THEN 'Teen'
       WHEN Age < 36 THEN 'Young Adult'
       WHEN Age < 61 THEN 'Adult' ELSE 'Senior' END AS age_group,
       ROUND(100.0*AVG(Survived),1) AS survival_rate
FROM train GROUP BY age_group;

-- ===== Chart 4 — Survival by port =====
SELECT Embarked, COUNT(*) AS total,
       ROUND(100.0*AVG(Survived),1) AS survival_rate
FROM train GROUP BY Embarked;

-- ===== Chart 5 — Family size =====
SELECT SibSp + Parch + 1 AS family_size,
       COUNT(*) AS total,
       ROUND(100.0*AVG(Survived),1) AS survival_rate
FROM train
GROUP BY family_size ORDER BY family_size;

-- ===== Chart 6 — Age distribution =====
SELECT CASE WHEN Survived=1 THEN 'Survived' ELSE 'Did not survive' END AS outcome,
       CASE WHEN Age < 13 THEN '0–12' WHEN Age < 20 THEN '13–19'
       WHEN Age < 36 THEN '20–35' WHEN Age < 61 THEN '36–60' ELSE '61+' END AS age_band,
       COUNT(*) AS passengers
FROM train GROUP BY outcome, age_band;

-- ===== Chart 7 — Survival by fare band =====
SELECT CASE WHEN Fare < 10 THEN '< $10'
       WHEN Fare < 30 THEN '$10–29' WHEN Fare < 60 THEN '$30–59' ELSE '$60+' END AS fare_band,
       COUNT(*) AS total,
       ROUND(100.0*AVG(Survived),1) AS survival_rate
FROM train GROUP BY fare_band;

-- ===== Chart 8 — Survival by deck =====
SELECT SUBSTR(Cabin,1,1) AS deck,
       COUNT(*) AS total,
       ROUND(100.0*AVG(Survived),1) AS survival_rate
FROM train WHERE Cabin IS NOT NULL
GROUP BY deck ORDER BY deck;

-- ===== Chart 9 — Passenger count by age group =====
SELECT CASE WHEN Age < 13 THEN 'Child'
       WHEN Age < 20 THEN 'Teen' WHEN Age < 36 THEN 'Young Adult'
       WHEN Age < 61 THEN 'Adult' ELSE 'Senior' END AS age_group,
       COUNT(*) AS passengers
FROM train GROUP BY age_group;

-- ===== Chart 10 — Outcome count =====
SELECT CASE WHEN Survived=1 THEN 'Survived' ELSE 'Did not survive' END AS outcome,
       COUNT(*) AS passengers
FROM train GROUP BY Survived;

-- ===== Combined comparison — Sex and class =====
SELECT Sex, Pclass, COUNT(*) AS total,
       SUM(Survived) AS survived,
       ROUND(100.0*AVG(Survived),1) AS survival_rate
FROM train GROUP BY Sex, Pclass
ORDER BY Sex, Pclass;
