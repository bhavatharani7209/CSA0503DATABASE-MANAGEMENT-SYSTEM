-- Normalised structure from the ER diagram (PASSENGER -> CLASS, PASSENGER -> PORT)
CREATE TABLE class(Pclass INTEGER PRIMARY KEY, Class_Name TEXT);
INSERT INTO class VALUES (1,'First'),(2,'Second'),(3,'Third');

CREATE TABLE port(Embarked TEXT PRIMARY KEY, Port_Name TEXT, Country TEXT);
INSERT INTO port VALUES ('C','Cherbourg','France'),('Q','Queenstown','Ireland'),('S','Southampton','United Kingdom');

CREATE TABLE passenger(
  PassengerId INTEGER PRIMARY KEY,
  Name TEXT, Sex TEXT CHECK(Sex IN ('male','female')), Age REAL,
  SibSp INTEGER, Parch INTEGER, Ticket TEXT, Fare REAL, Cabin TEXT,
  Survived INTEGER CHECK(Survived IN (0,1)),
  Pclass INTEGER REFERENCES class(Pclass),
  Embarked TEXT REFERENCES port(Embarked)
);
