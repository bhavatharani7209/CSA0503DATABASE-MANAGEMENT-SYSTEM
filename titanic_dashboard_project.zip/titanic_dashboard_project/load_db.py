"""Builds titanic.db (SQLite) from data/train.csv so the SQL in sql/queries.sql can be run."""
import csv, sqlite3, os
here = os.path.dirname(os.path.abspath(__file__))
db = os.path.join(here, "titanic.db")
if os.path.exists(db): os.remove(db)
con = sqlite3.connect(db)
cols = ["PassengerId","Survived","Pclass","Name","Sex","Age","SibSp","Parch","Ticket","Fare","Cabin","Embarked"]
con.execute("CREATE TABLE train(PassengerId INTEGER, Survived INTEGER, Pclass INTEGER, Name TEXT, Sex TEXT, Age REAL, SibSp INTEGER, Parch INTEGER, Ticket TEXT, Fare REAL, Cabin TEXT, Embarked TEXT)")
with open(os.path.join(here, "data", "train.csv"), encoding="utf-8") as fh:
    rows = [[(v if v != "" else None) for v in (r[c] for c in cols)] for r in csv.DictReader(fh)]
con.executemany("INSERT INTO train VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", rows)
con.executescript(open(os.path.join(here, "sql", "schema.sql"), encoding="utf-8").read())
con.execute("INSERT INTO passenger SELECT PassengerId,Name,Sex,Age,SibSp,Parch,Ticket,Fare,Cabin,Survived,Pclass,Embarked FROM train")
con.commit()
print("titanic.db created:", con.execute("SELECT COUNT(*) FROM train").fetchone()[0], "rows")
