# Passenger Survival and Demographic Insights
Titanic DBMS analysis dashboard. Done by Bhavatharanui.H and Tejaswini.K.N

## Run
Open `index.html` in any browser. No server, install or internet connection is needed.

## Structure
- `index.html`      page layout and navigation
- `css/style.css`   styles (light/dark/print)
- `js/data.js`      embedded train.csv (891 rows, 12 columns)
- `js/app.js`       cleaning, analysis, 10 SVG charts, reports, SQL and ER views
- `data/train.csv`  the same dataset as CSV (can also be uploaded in Module 1)
- `sql/queries.sql` all SQL used for each module and chart
- `sql/schema.sql`  normalised PASSENGER / CLASS / PORT tables from the ER diagram
- `load_db.py`      builds `titanic.db` (SQLite) from the CSV: `python load_db.py`

## Modules
1. Data and Cleaning  2. Analysis  3. Charts and Reports  4. Queries and ER Diagram
